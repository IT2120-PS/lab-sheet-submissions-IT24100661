setwd("/Users/aksharaparami/Desktop/IT24100661")
getwd()

#1
punif(15, min=10, max=25, lower.tail = TRUE)

#2
pexp(2, rate = 0.333, lower.tail = TRUE)

#3
#(i)
pnorm(130, mean=100, sd=15, lower.tail = TRUE)

#(ii)
qnorm(0.95, mean=100, sd=15, lower.tail = TRUE)
